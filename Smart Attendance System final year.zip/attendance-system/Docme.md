# 🧠 Smart Attendance System (AI-Powered)

## 📖 Project Overview
This project is a **Face Recognition-based Attendance System** built using Python. Unlike traditional systems that use older, less accurate methods (like LBPH), this system utilizes **State-of-the-Art Deep Learning models** (YuNet and SFace) to achieve **99% accuracy** in real-time.

The system allows you to:
1.  **Register Students:** Capture face biometric data via webcam.
2.  **Train the AI:** Convert face images into mathematical vectors (embeddings).
3.  **Mark Attendance:** Recognize faces in real-time and save logs to a database.
4.  **View Reports:** Export attendance sheets as CSV/Excel.

---

## 🛠️ Technology Stack (Why we chose these tools)

| Component | Tool Used | Why? |
| :--- | :--- | :--- |
| **Interface (Frontend)** | `Streamlit` | It creates a modern, responsive web dashboard instantly using Python code. Much better looking than old Tkinter windows. |
| **Face Detection** | `YuNet` (OpenCV DNN) | A deep learning model that finds faces even in bad lighting or side angles. It is far superior to "Haar Cascades". |
| **Face Recognition** | `SFace` (OpenCV DNN) | A neural network that maps a face to a "vector". It has 99% accuracy on standard benchmarks. |
| **Database** | `SQLite` | A lightweight, serverless database that stores student records and logs without needing complex installation. |
| **Data Handling** | `Pandas` | Used to generate clean Excel-like reports from the database logs. |

---

## 📂 Project Structure Explained

Here is what every file and folder does. This is critical for understanding the workflow.

### 1. The Core Code Files 💻
* **`ui.py`** (The Face)
    * This is the **Main Application**. It uses Streamlit to draw the buttons, the webcam view, and the tables you see in the browser.
    * It talks to `face_engine.py` to get predictions and `database.py` to save them.

* **`face_engine.py`** (The Brain 🧠)
    * This is where the AI lives. It loads the **YuNet** and **SFace** models.
    * **What it does:** It takes an image, finds the face, converts it into a list of numbers (biometric features), and compares those numbers to the known students to find a match.

* **`database.py`** (The Memory 💾)
    * Handles all SQL operations. It creates the `attendance.db` file to store student names, IDs, and timestamps.
    * Ensures that a student isn't marked "Present" twice in the same minute.

### 2. The Data Folders 📁
* **`dataset/`**:
    * Stores the raw images captured when you add a new student.
    * Format: `User.ID.Count.jpg` (e.g., `User.101.5.jpg`).

* **`models/`**:
    * Contains the pre-trained Deep Learning networks (`.onnx` files).
    * *Note:* The system downloads these automatically if they are missing.

* **`trainer/`**:
    * **`encodings.pkl`**: This is the "Knowledge File". After training, the AI saves the mathematical data of all students here. When recognizing, it only looks at this file, not the images.
    * **`names.pkl`**: A simple dictionary mapping IDs (e.g., `101`) to Names (e.g., `John Doe`).

* **`attendance_logs/`**:
    * (Optional) Folder where daily CSV reports can be exported.

---

## 🚀 How It Works (The "AI Pipeline")

When you click **"Recognize"**, the system performs these 4 steps in milliseconds:

1.  **Input:** The webcam captures a single frame (image).
2.  **Detection (YuNet):** The AI scans the image to find the coordinates `(x, y)` of a face. If no face is found, it stops.
3.  **Feature Extraction (SFace):** The face is cropped and fed into the Neural Network. The network outputs a **Feature Vector** (a unique digital signature of that face).
4.  **Matching (Cosine Similarity):** This new vector is compared mathematically against the saved vectors in `encodings.pkl`.
    * If the similarity score is **> 0.363**, it's a **Match**.
    * If less, it is **Unknown**.

---

## ⚡ How to Run

1.  **Install Requirements:**
    ```bash
    pip install -r requirements.txt
    ```

2.  **Start the App:**
    ```bash
    streamlit run ui.py
    ```

3.  **Access:**
    Open your browser at the URL shown (usually `http://localhost:8501`).

---

## 📝 Tips for Best Accuracy
* **Lighting:** Ensure the face is evenly lit. Backlighting (window behind you) makes detection hard.
* **Angles:** When adding a student, capture photos looking slightly left, right, up, and down. This teaches the AI the 3D structure of your face.