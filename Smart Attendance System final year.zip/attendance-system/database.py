import sqlite3
from datetime import datetime
import pandas as pd
from typing import Optional, Tuple, List

DB_PATH = 'attendance.db'

class AttendanceDB:
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self._init_db()

    def _init_db(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER,
                name TEXT,
                date DATE,
                time TIME,
                status TEXT DEFAULT 'Present',
                FOREIGN KEY (student_id) REFERENCES students (id)
            )
        ''')
        self.conn.commit()

    def add_student(self, student_id: int, name: str) -> None:
        self.cursor.execute(
            "INSERT OR REPLACE INTO students (id, name) VALUES (?, ?)",
            (student_id, name)
        )
        self.conn.commit()

    def list_students(self) -> List[Tuple[int, str]]:
        self.cursor.execute("SELECT id, name FROM students ORDER BY id")
        return self.cursor.fetchall()

    def mark_attendance(self, student_id: int, name: str) -> bool:
        now = datetime.now()
        date = now.strftime('%Y-%m-%d')
        time = now.strftime('%H:%M:%S')
        self.cursor.execute(
            "SELECT 1 FROM attendance WHERE student_id = ? AND date = ?",
            (student_id, date)
        )
        if self.cursor.fetchone() is None:
            self.cursor.execute(
                """
                INSERT INTO attendance (student_id, name, date, time, status)
                VALUES (?, ?, ?, ?, 'Present')
                """,
                (student_id, name, date, time)
            )
            self.conn.commit()
            return True
        return False

    def generate_attendance_report(self, date: Optional[str] = None) -> pd.DataFrame:
        if date is None:
            date = datetime.now().strftime('%Y-%m-%d')
        query = (
            "SELECT student_id, name, date, time, status FROM attendance WHERE date = ? ORDER BY time"
        )
        df = pd.read_sql_query(query, self.conn, params=[date])
        return df

    def close(self):
        try:
            self.conn.close()
        except Exception:
            pass
