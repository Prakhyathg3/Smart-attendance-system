import io
import time
from datetime import datetime

import cv2
import numpy as np
import pandas as pd
import streamlit as st

from database import AttendanceDB
from face_engine import FaceEngine

st.set_page_config(page_title="Smart Attendance", page_icon="🧠", layout="wide")

# Lazy singletons with clear option for refresh
@st.cache_resource(ttl=1)  # 1 second time-to-live
def get_db():
    return AttendanceDB()

@st.cache_resource
def get_engine():
    return FaceEngine()


def bgr_from_uploaded(file) -> np.ndarray:
    bytes_data = file.read()
    file.seek(0)
    nparr = np.frombuffer(bytes_data, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    return img


def bgr_from_camera_input(img_bytes: bytes) -> np.ndarray:
    nparr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    return img


st.title("Smart Attendance System")

# Sidebar navigation
page = st.sidebar.radio(
    "Navigate",
    ["Add Student", "Train Model", "Recognize & Mark", "View Attendance", "Students"],
)

engine = get_engine()
db = get_db()

if page == "Add Student":
    st.subheader("Add New Student & Capture Samples")
    col1, col2 = st.columns(2)
    with col1:
        student_id = st.number_input("Student ID", min_value=1, step=1)
        name = st.text_input("Name")
        samples = st.number_input("Samples to capture", min_value=1, max_value=30, value=5)
    with col2:
        st.markdown("Upload photos or use camera to capture faces. Clear, front-facing images work best.")

    st.markdown("### Capture via Camera")
    camera_img = st.camera_input("Take a photo")

    st.markdown("### Or Upload Images")
    uploads = st.file_uploader("Select one or more images", type=["jpg", "jpeg", "png"], accept_multiple_files=True)

    if st.button("Save Samples"):
        if not name.strip():
            st.error("Please enter a name.")
        else:
            engine.add_or_update_name(int(student_id), name.strip())
            saved = 0
            # From camera
            if camera_img is not None:
                img_bgr = bgr_from_camera_input(camera_img.getvalue())
                saved += engine.save_face_sample(int(student_id), img_bgr)
            # From uploads
            for up in uploads or []:
                img_bgr = bgr_from_uploaded(up)
                saved += engine.save_face_sample(int(student_id), img_bgr)
            # If not enough samples, inform user
            if saved == 0:
                st.warning("No faces detected. Try different photos or better lighting.")
            else:
                # Also add to DB
                db.add_student(int(student_id), name.strip())
                st.success(f"Saved {saved} face sample(s) for {name}.")

elif page == "Train Model":
    st.subheader("Train Face Recognizer")
    if st.button("Train"):
        try:
            n = engine.train_model()
            st.success(f"Training complete. Trained {n} unique face(s).")
        except Exception as e:
            st.error(str(e))

elif page == "Recognize & Mark":
    st.subheader("Recognize from Camera & Mark Attendance")
    st.write("Take a photo, then click 'Recognize'. If recognized confidently, you can mark attendance.")

    camera_img = st.camera_input("Take a photo")

    recognized_name = None
    confidence = 0.0

    if st.button("Recognize"):
        if camera_img is None:
            st.warning("Please capture a photo first.")
        else:
            img_bgr = bgr_from_camera_input(camera_img.getvalue())
            name, conf = engine.recognize(img_bgr)
            recognized_name, confidence = name, conf
            st.info(f"Prediction: {name} (confidence ~ {conf:.1f}%)")

            # Autofill student if exact match exists in names
            if name.startswith("Unknown") or name in ("No face", "Model not trained"):
                pass
            else:
                # find id for this name
                sid = None
                for k, v in engine.names.items():
                    if v == name:
                        sid = k
                        break
                if sid is not None:
                    st.session_state["predicted_id"] = sid
                    st.session_state["predicted_name"] = name

    # Mark attendance section
    pid = st.session_state.get("predicted_id")
    pname = st.session_state.get("predicted_name")

    colA, colB = st.columns(2)
    with colA:
        manual_id = st.number_input("Student ID (override or confirm)", min_value=1, step=1, value=int(pid) if pid else 1)
    with colB:
        manual_name = st.text_input("Name (override or confirm)", value=pname or "")

    if st.button("Mark Attendance"):
        if not manual_name.strip():
            st.error("Name required to mark attendance.")
        else:
            # ensure mapping exists
            engine.add_or_update_name(int(manual_id), manual_name.strip())
            # ensure student exists in DB as well
            db.add_student(int(manual_id), manual_name.strip())
            added = db.mark_attendance(int(manual_id), manual_name.strip())
            if added:
                st.success(f"Attendance marked for {manual_name}.")
            else:
                st.warning(f"{manual_name} already marked present today.")

elif page == "View Attendance":
    st.subheader("Attendance Report")
    
    # Add refresh button at the top
    if st.button("Refresh Data"):
        st.session_state["_refresh_toggle"] = not st.session_state.get("_refresh_toggle", False)
        st.rerun()
        
    date = st.date_input("Date", value=datetime.now().date())
    
    # Get fresh data on each refresh
    @st.cache_data(ttl=1)  # 1 second time-to-live
    def get_attendance_report(date_str: str, refresh_toggle: bool):
        # Force new DB connection
        fresh_db = AttendanceDB()
        return fresh_db.generate_attendance_report(date_str)
    
    refresh_toggle = st.session_state.get("_refresh_toggle", False)
    df = get_attendance_report(str(date), refresh_toggle)
    
    if df.empty:
        st.info("No records for selected date.")
    else:
        st.dataframe(df, use_container_width=True)
        csv = df.to_csv(index=False).encode('utf-8')
        st.download_button("Download CSV", data=csv, file_name=f"attendance_{date}.csv", mime="text/csv")

elif page == "Students":
    st.subheader("Registered Students")
    students = db.list_students()
    if not students:
        st.info("No students registered yet.")
    else:
        df = pd.DataFrame(students, columns=["ID", "Name"]) 
        st.dataframe(df, use_container_width=True)
